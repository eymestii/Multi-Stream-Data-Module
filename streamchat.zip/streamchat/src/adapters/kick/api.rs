//! Cliente mínimo de la API pública de Kick.

use anyhow::{bail, Context, Result};
use reqwest::Client;
use serde::Deserialize;
use serde_json::{json, Value};

use crate::config::KickConfig;
use crate::proto::v1::SendMessageResponse;

const API: &str = "https://api.kick.com/public/v1";

#[derive(Clone)]
pub struct KickApi {
    http: Client,
    access_token: Option<String>,
    send_as: String,
}

impl KickApi {
    pub fn new(http: Client, cfg: &KickConfig) -> Self {
        Self {
            http,
            access_token: cfg.access_token.clone(),
            send_as: cfg.send_as.clone(),
        }
    }

    pub fn http(&self) -> &Client {
        &self.http
    }

    fn token(&self) -> Result<&str> {
        self.access_token
            .as_deref()
            .context("KICK_ACCESS_TOKEN no está configurado")
    }

    /// Suscribe un canal a eventos entregados por webhook. La URL de destino
    /// se configura en la app de Kick (kick.com/settings/developer).
    pub async fn subscribe_events(&self, broadcaster_id: &str, events: &[(&str, u32)]) -> Result<()> {
        let broadcaster_user_id: u64 = broadcaster_id
            .parse()
            .with_context(|| format!("el id de canal de Kick {broadcaster_id:?} debe ser numérico"))?;
        let events: Vec<Value> = events
            .iter()
            .map(|(name, version)| json!({ "name": name, "version": version }))
            .collect();

        let resp = self
            .http
            .post(format!("{API}/events/subscriptions"))
            .bearer_auth(self.token()?)
            .json(&json!({
                "broadcaster_user_id": broadcaster_user_id,
                "events": events,
                "method": "webhook",
            }))
            .send()
            .await
            .context("no se pudo contactar a la API de Kick")?;

        let status = resp.status();
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            bail!("Kick respondió {status}: {body}");
        }
        Ok(())
    }

    /// Envía un mensaje al chat. Con `KICK_SEND_AS=bot`, Kick lo publica en el canal
    /// asociado al token; con `user`, en el canal indicado por `broadcaster_id`.
    pub async fn send_chat_message(
        &self,
        broadcaster_id: &str,
        text: &str,
        reply_to: Option<&str>,
    ) -> Result<SendMessageResponse> {
        let broadcaster_user_id: u64 = broadcaster_id
            .parse()
            .context("channel_id de Kick debe ser numérico")?;
        let mut body = json!({
            "broadcaster_user_id": broadcaster_user_id,
            "content": text,
            "type": self.send_as,
        });
        if let Some(parent) = reply_to {
            body["reply_to_message_id"] = json!(parent);
        }

        let resp = self
            .http
            .post(format!("{API}/chat"))
            .bearer_auth(self.token()?)
            .json(&body)
            .send()
            .await?;
        let status = resp.status();
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            bail!("Kick respondió {status}: {body}");
        }

        #[derive(Deserialize)]
        struct Envelope {
            data: Data,
        }
        #[derive(Deserialize)]
        struct Data {
            #[serde(default)]
            is_sent: bool,
            #[serde(default)]
            message_id: String,
        }

        let envelope: Envelope = resp.json().await.context("respuesta inesperada de Kick")?;
        Ok(SendMessageResponse {
            message_id: envelope.data.message_id,
            accepted: envelope.data.is_sent,
            drop_reason: String::new(),
        })
    }
}

/// Descarga la clave pública con la que Kick firma los webhooks.
pub async fn fetch_public_key(http: &Client) -> Result<String> {
    #[derive(Deserialize)]
    struct Envelope {
        data: Data,
    }
    #[derive(Deserialize)]
    struct Data {
        public_key: String,
    }

    let resp = http.get(format!("{API}/public-key")).send().await?;
    let status = resp.status();
    if !status.is_success() {
        bail!("Kick respondió {status} al pedir la clave pública");
    }
    let envelope: Envelope = resp.json().await.context("respuesta inesperada de Kick")?;
    Ok(envelope.data.public_key)
}
