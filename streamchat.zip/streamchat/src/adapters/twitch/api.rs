//! Cliente mínimo de la API Helix de Twitch.

use anyhow::{bail, Context, Result};
use reqwest::{Client, RequestBuilder, StatusCode};
use serde::Deserialize;
use serde_json::{json, Value};

use crate::config::TwitchConfig;
use crate::proto::v1::SendMessageResponse;

const HELIX: &str = "https://api.twitch.tv/helix";

#[derive(Clone)]
pub struct TwitchApi {
    http: Client,
    client_id: String,
    access_token: String,
    bot_user_id: String,
}

impl TwitchApi {
    pub fn new(http: Client, cfg: &TwitchConfig) -> Self {
        Self {
            http,
            client_id: cfg.client_id.clone(),
            access_token: cfg.access_token.clone(),
            bot_user_id: cfg.bot_user_id.clone(),
        }
    }

    pub fn bot_user_id(&self) -> &str {
        &self.bot_user_id
    }

    fn post(&self, path: &str) -> RequestBuilder {
        self.http
            .post(format!("{HELIX}{path}"))
            .bearer_auth(&self.access_token)
            .header("Client-Id", &self.client_id)
    }

    /// Crea una suscripción EventSub ligada a la sesión de WebSocket.
    pub async fn create_subscription(
        &self,
        session_id: &str,
        sub_type: &str,
        version: &str,
        condition: Value,
    ) -> Result<()> {
        let resp = self
            .post("/eventsub/subscriptions")
            .json(&json!({
                "type": sub_type,
                "version": version,
                "condition": condition,
                "transport": { "method": "websocket", "session_id": session_id },
            }))
            .send()
            .await
            .context("no se pudo contactar a Helix")?;

        match resp.status() {
            s if s.is_success() => Ok(()),
            // Ya existía: no es un error.
            StatusCode::CONFLICT => Ok(()),
            s => {
                let body = resp.text().await.unwrap_or_default();
                bail!("Helix respondió {s}: {body}")
            }
        }
    }

    /// Envía un mensaje al chat como el usuario del bot (scope `user:write:chat`).
    pub async fn send_chat_message(
        &self,
        broadcaster_id: &str,
        text: &str,
        reply_to: Option<&str>,
    ) -> Result<SendMessageResponse> {
        let mut body = json!({
            "broadcaster_id": broadcaster_id,
            "sender_id": self.bot_user_id,
            "message": text,
        });
        if let Some(parent) = reply_to {
            body["reply_parent_message_id"] = json!(parent);
        }

        let resp = self.post("/chat/messages").json(&body).send().await?;
        let status = resp.status();
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            bail!("Helix respondió {status}: {body}");
        }

        #[derive(Deserialize)]
        struct Envelope {
            data: Vec<Item>,
        }
        #[derive(Deserialize)]
        struct Item {
            #[serde(default)]
            message_id: String,
            is_sent: bool,
            drop_reason: Option<DropReason>,
        }
        #[derive(Deserialize)]
        struct DropReason {
            #[serde(default)]
            code: String,
            #[serde(default)]
            message: String,
        }

        let envelope: Envelope = resp.json().await.context("respuesta inesperada de Helix")?;
        let item = envelope.data.into_iter().next().context("Helix devolvió data vacío")?;
        Ok(SendMessageResponse {
            message_id: item.message_id,
            accepted: item.is_sent,
            drop_reason: item
                .drop_reason
                .map(|d| format!("{}: {}", d.code, d.message))
                .unwrap_or_default(),
        })
    }
}
