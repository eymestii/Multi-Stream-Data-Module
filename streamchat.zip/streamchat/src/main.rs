mod adapters;
mod config;
mod grpc;
mod hub;
mod outbound;
mod proto;
mod util;

use std::sync::Arc;
use std::time::Duration;

use anyhow::{Context, Result};
use tokio::task::JoinSet;
use tokio_util::sync::CancellationToken;
use tracing::{error, info, warn};
use tracing_subscriber::EnvFilter;

use adapters::{kick::api::KickApi, twitch::api::TwitchApi};
use config::Config;
use hub::Hub;
use outbound::Outbound;
use proto::v1::{chat_hub_server::ChatHubServer, Channel, Platform};

#[tokio::main]
async fn main() -> Result<()> {
    // Carga `.env` si existe; las variables ya definidas en el entorno tienen prioridad.
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()))
        .init();

    let cfg = Config::from_env().context("configuración inválida")?;
    let hub = Hub::new(cfg.event_buffer_size, cfg.subscriber_queue_size, cfg.include_raw_json);
    let cancel = CancellationToken::new();
    let mut tasks: JoinSet<Result<()>> = JoinSet::new();

    let http = reqwest::Client::builder()
        .user_agent(concat!("streamchat/", env!("CARGO_PKG_VERSION")))
        .timeout(Duration::from_secs(10))
        .build()?;
    let mut outbound = Outbound::default();

    // ---- Capa 1: adaptadores ----
    if let Some(tc) = cfg.twitch.clone() {
        let api = TwitchApi::new(http.clone(), &tc);
        outbound.twitch = Some(api.clone());
        for id in &tc.broadcaster_ids {
            hub.register_channel(Channel {
                platform: Platform::Twitch as i32,
                id: id.clone(),
                ..Default::default()
            });
        }
        tasks.spawn(adapters::twitch::run(tc, api, hub.clone(), cancel.clone()));
    }
    if let Some(kc) = cfg.kick.clone() {
        let api = KickApi::new(http.clone(), &kc);
        outbound.kick = Some(api.clone());
        tasks.spawn(adapters::kick::run(kc, api, hub.clone(), cancel.clone()));
    }
    if let Some(mc) = cfg.mock.clone() {
        tasks.spawn(adapters::mock::run(mc, hub.clone(), cancel.clone()));
    }
    if cfg.twitch.is_none() && cfg.kick.is_none() && cfg.mock.is_none() {
        warn!("no hay fuentes habilitadas: activa TWITCH_ENABLED, KICK_ENABLED o MOCK_EVENTS");
    }

    // ---- Capa 4: servidor gRPC ----
    let service = grpc::ChatHubService::new(hub.clone(), Arc::new(outbound));
    let reflection = tonic_reflection::server::Builder::configure()
        .register_encoded_file_descriptor_set(proto::FILE_DESCRIPTOR_SET)
        .build_v1()?;
    let grpc_addr = cfg.grpc_addr;
    let shutdown = cancel.clone();
    tasks.spawn(async move {
        info!(addr = %grpc_addr, "gRPC: servidor escuchando");
        tonic::transport::Server::builder()
            .add_service(reflection)
            .add_service(ChatHubServer::new(service))
            .serve_with_shutdown(grpc_addr, shutdown.cancelled_owned())
            .await
            .context("el servidor gRPC falló")
    });

    // Corre hasta Ctrl+C o hasta que alguna tarea termine (lo que indica un problema).
    tokio::select! {
        _ = shutdown_signal() => info!("señal de apagado recibida"),
        Some(result) = tasks.join_next() => match result {
            Ok(Ok(())) => warn!("una tarea terminó inesperadamente"),
            Ok(Err(e)) => error!(error = %format!("{e:#}"), "una tarea falló"),
            Err(e) => error!(error = %e, "una tarea entró en pánico"),
        },
    }

    cancel.cancel();
    while let Some(result) = tasks.join_next().await {
        if let Ok(Err(e)) = result {
            error!(error = %format!("{e:#}"), "error al detener una tarea");
        }
    }
    info!("apagado completo");
    Ok(())
}

async fn shutdown_signal() {
    let ctrl_c = async {
        let _ = tokio::signal::ctrl_c().await;
    };
    #[cfg(unix)]
    let terminate = async {
        match tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate()) {
            Ok(mut s) => {
                s.recv().await;
            }
            Err(_) => std::future::pending::<()>().await,
        }
    };
    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => {},
        _ = terminate => {},
    }
}
